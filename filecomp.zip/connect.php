  
<?php
$conn = mysqli_connect("localhost","id15395006_ani","Ani@9920959596","id15395006_mobilecom");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }

?>